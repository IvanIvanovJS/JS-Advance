import { html } from "../../node_modules/lit-html/lit-html.js";
import { createSolution } from "../api/dataService.js";

import { createSubmitHandler } from "../service/formService.js";

const temp = (ctx) => html` <section id="create">
          <div class="form">
            <img class="border" src="/images/border.png" alt="" />
            <h2>Add Solution</h2>
            <form class="create-form" @submit=${createSubmitHandler(onSubmit.bind(null, ctx))}>
              <input
                type="text"
                name="type"
                id="type"
                placeholder="Solution Type"
              />
              <input
                type="text"
                name="image-url"
                id="image-url"
                placeholder="Image URL"
              />
              <textarea
                id="description"
                name="description"
                placeholder="Description"
                rows="2"
                cols="10"
              ></textarea>
              <textarea
                id="more-info"
                name="more-info"
                placeholder="more Info"
                rows="2"
                cols="10"
              ></textarea>
              <button type="submit">Add Solution</button>
            </form>
          </div>
        </section>`
export function showCreate(ctx) {
  ctx.render(temp(ctx))
}

async function onSubmit(ctx, data) {

  const { type, description } = data
  const learnMore = data["more-info"]
  const imageUrl = data["image-url"]

  try {
    if (!type || !description || !learnMore || !imageUrl) {
      throw new Error("All fields are reqierd!")
    }
    console.log(type, imageUrl, description, learnMore);

    await createSolution({ type, imageUrl, description, learnMore })
    ctx.page.redirect('/dashboard')
  } catch (error) {
    return alert(error.message)
  }


}